import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewvideoplayPage } from './viewvideoplay';

@NgModule({
  declarations: [
    ViewvideoplayPage,
  ],
  imports: [
    IonicPageModule.forChild(ViewvideoplayPage),
  ],
})
export class ViewvideoplayPageModule {}
