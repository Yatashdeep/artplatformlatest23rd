import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ViewController } from 'ionic-angular';
import {DomSanitizer} from '@angular/platform-browser';
/**
 * Generated class for the ViewvideoplayPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-viewvideoplay',
  templateUrl: 'viewvideoplay.html',
})
export class ViewvideoplayPage {
id
data
usertype
pathurl
iframe
pathsantiz
  constructor(public santizer:DomSanitizer,public viewCtrl:ViewController,public navCtrl: NavController, public navParams: NavParams) {
    this.iframe=false
  }

  ionViewDidLoad() {
    this.id=this.navParams.get('id');
    this.data=this.navParams.get('data');
    var str=this.data[this.id].mediaplay
    var n=str.search('youtu.be');
    console.log('str',str)
    if(n==-1) {
      this.pathurl=this.data[this.id].mediaplay

      console.log('data',this.data[this.id])
      // this.iframe=true
      // var res = this.data[this.id].mediaplay.split("https://www.youtube.com/watch?v=");  
      // var youtubeurl='http://www.youtube.com/embed/'+res
      // var youtuberes=youtubeurl.replace(",", "");
      // this.pathsantiz=this.santizer.bypassSecurityTrustResourceUrl(youtuberes+'?autoplay=1');
      // this.pathurl=this.pathsantiz
    }
    else {
      this.iframe=true
     // var res = this.data[this.id].mediaplay.split("https://www.youtube.com/watch?v=");
    //  console.log('mediaplay',this.data[this.id].mediaplay)
//        var str=this.data[this.id].mediaplay
//        var n=str.search('http://youtu.be')
//       if(n!=-1)
//       {
//         console.log('if',res)
//         var res = this.data[this.id].mediaplay.split("http://youtu.be/");
//       }
//       else
//       {
//         console.log('else',res)
//       var res = this.data[this.id].mediaplay.split("https://youtu.be/");
//       }
//       var youtubeurl='http://www.youtube.com/embed/'+res
//       var youtuberes=youtubeurl.replace(",", "");
//      alert('youtuberes'+youtuberes)
//       // this.pathsantiz=this.santizer.bypassSecurityTrustUrl(this.pathurl);
//       // console.log('path'+this.pathsantiz) 
//       // this.pathurl=this.data[this.id].UserMedia.usermedia_path
// //      this.pathsantiz=this.santizer.bypassSecurityTrustResourceUrl(youtuberes);
//       this.pathsantiz=this.santizer.bypassSecurityTrustResourceUrl(youtuberes+'?autoplay=1');
//       this.pathurl=this.pathsantiz
var str1=this.data[this.id].mediaplay
var n1=str1.search('watch')
if(n1!=-1)
{
var res = this.data[this.id].mediaplay.split("https://www.youtube.com/watch?v=");
console.log('ifstatement'+res)
var youtubeurl='https://www.youtube.com/embed/'+res
var youtuberes=youtubeurl.replace(",", "");
console.log('youtubers'+youtuberes)
//  this.pathsantiz=this.santizer.bypassSecurityTrustResourceUrl(youtuberes)

this.pathsantiz=this.santizer.bypassSecurityTrustResourceUrl(youtuberes+'?autoplay=1')
}
else
{                                                         
  var res = this.data[this.id].mediaplay.split("https://youtu.be/");
  console.log('elsestatement'+res)
  var youtubeurl='https://www.youtube.com/embed/'+res
  var youtuberes1=youtubeurl.replace(",", "");
//  var youtuberes1=this.data[this.id].media_thumbnail_url
  // var res = this.data[this.id].media_thumbnail_url.split("https://www.youtube.com/watch?v=");
  // console.log('hope'+res)
  // var youtubeurl='https://www.youtube.com/embed/'+res
  // var youtuberes=youtubeurl.replace(",", "");
  // console.log('youtubers'+youtuberes)
//  this.pathsantiz=this.santizer.bypassSecurityTrustResourceUrl(youtuberes)
  console.log('you',youtuberes1)
  this.pathsantiz=this.santizer.bypassSecurityTrustResourceUrl(youtuberes1+'?autoplay=1')
}
    }
    this.usertype=this.data[this.id].media_type
    console.log('ionViewDidLoad ViewvideoplayPage');
  }

  close(){
    this.viewCtrl.dismiss()
  }

}
