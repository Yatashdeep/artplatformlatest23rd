import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChoosecatpagetabPage } from './choosecatpagetab';

@NgModule({
  declarations: [
    ChoosecatpagetabPage,
  ],
  imports: [
    IonicPageModule.forChild(ChoosecatpagetabPage),
  ],
})
export class ChoosecatpagetabPageModule {}
